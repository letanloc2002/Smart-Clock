# STM32_MAX7219_SPI
Library for 7 segmented LED display STM32 MAX7219 SPI
https://stm32withoutfear.blogspot.com/2019/06/stm32-7segments-8digits-max7219-spi.html
